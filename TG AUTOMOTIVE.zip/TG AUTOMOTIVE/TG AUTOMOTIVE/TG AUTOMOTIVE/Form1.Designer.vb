﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkLubeJob = New System.Windows.Forms.CheckBox()
        Me.chkOilChnge = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtLabor = New System.Windows.Forms.TextBox()
        Me.txtParts = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.chkTireRotation = New System.Windows.Forms.CheckBox()
        Me.chkReplaceMuff = New System.Windows.Forms.CheckBox()
        Me.chkInspection = New System.Windows.Forms.CheckBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblTotalOutptut = New System.Windows.Forms.Label()
        Me.lblTaxOnPartsOutput = New System.Windows.Forms.Label()
        Me.lblPartsOutput = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblServiceLaborOutput = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.chkTranFlush = New System.Windows.Forms.CheckBox()
        Me.chkRadFlush = New System.Windows.Forms.CheckBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(3, 370)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(110, 42)
        Me.btnCalc.TabIndex = 5
        Me.btnCalc.Text = "CALCULATE"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(188, 370)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(110, 42)
        Me.btnClear.TabIndex = 6
        Me.btnClear.Text = "CLEAR"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(381, 370)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(110, 42)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkLubeJob)
        Me.GroupBox1.Controls.Add(Me.chkOilChnge)
        Me.GroupBox1.Location = New System.Drawing.Point(28, 32)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "OIL AND LUBERICATION"
        '
        'chkLubeJob
        '
        Me.chkLubeJob.AutoSize = True
        Me.chkLubeJob.Location = New System.Drawing.Point(19, 67)
        Me.chkLubeJob.Name = "chkLubeJob"
        Me.chkLubeJob.Size = New System.Drawing.Size(77, 17)
        Me.chkLubeJob.TabIndex = 11
        Me.chkLubeJob.Text = "LUBE JOB"
        Me.chkLubeJob.UseVisualStyleBackColor = True
        '
        'chkOilChnge
        '
        Me.chkOilChnge.AutoSize = True
        Me.chkOilChnge.Location = New System.Drawing.Point(19, 31)
        Me.chkOilChnge.Name = "chkOilChnge"
        Me.chkOilChnge.Size = New System.Drawing.Size(91, 17)
        Me.chkOilChnge.TabIndex = 10
        Me.chkOilChnge.Text = "OIL CHANGE"
        Me.chkOilChnge.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.txtLabor)
        Me.GroupBox2.Controls.Add(Me.txtParts)
        Me.GroupBox2.Location = New System.Drawing.Point(266, 138)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(223, 100)
        Me.GroupBox2.TabIndex = 9
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "PARTS AND LABOR"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(166, 58)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(27, 13)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "MIN"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(7, 58)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(43, 13)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "LABOR"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(7, 32)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(43, 13)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "PARTS"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(166, 32)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(13, 13)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "$"
        '
        'txtLabor
        '
        Me.txtLabor.Location = New System.Drawing.Point(60, 62)
        Me.txtLabor.Name = "txtLabor"
        Me.txtLabor.Size = New System.Drawing.Size(100, 20)
        Me.txtLabor.TabIndex = 16
        '
        'txtParts
        '
        Me.txtParts.Location = New System.Drawing.Point(60, 29)
        Me.txtParts.Name = "txtParts"
        Me.txtParts.Size = New System.Drawing.Size(100, 20)
        Me.txtParts.TabIndex = 15
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.chkTireRotation)
        Me.GroupBox3.Controls.Add(Me.chkReplaceMuff)
        Me.GroupBox3.Controls.Add(Me.chkInspection)
        Me.GroupBox3.Location = New System.Drawing.Point(28, 138)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox3.TabIndex = 9
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "MISCELLANEOUS"
        '
        'chkTireRotation
        '
        Me.chkTireRotation.AutoSize = True
        Me.chkTireRotation.Location = New System.Drawing.Point(19, 65)
        Me.chkTireRotation.Name = "chkTireRotation"
        Me.chkTireRotation.Size = New System.Drawing.Size(110, 17)
        Me.chkTireRotation.TabIndex = 14
        Me.chkTireRotation.Text = "TIRE ROTATION"
        Me.chkTireRotation.UseVisualStyleBackColor = True
        '
        'chkReplaceMuff
        '
        Me.chkReplaceMuff.AutoSize = True
        Me.chkReplaceMuff.Location = New System.Drawing.Point(19, 42)
        Me.chkReplaceMuff.Name = "chkReplaceMuff"
        Me.chkReplaceMuff.Size = New System.Drawing.Size(128, 17)
        Me.chkReplaceMuff.TabIndex = 13
        Me.chkReplaceMuff.Text = "REPLACE MUFFLER"
        Me.chkReplaceMuff.UseVisualStyleBackColor = True
        '
        'chkInspection
        '
        Me.chkInspection.AutoSize = True
        Me.chkInspection.Location = New System.Drawing.Point(19, 19)
        Me.chkInspection.Name = "chkInspection"
        Me.chkInspection.Size = New System.Drawing.Size(91, 17)
        Me.chkInspection.TabIndex = 12
        Me.chkInspection.Text = "INSPECTION"
        Me.chkInspection.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label2)
        Me.GroupBox4.Controls.Add(Me.Label4)
        Me.GroupBox4.Controls.Add(Me.lblTotalOutptut)
        Me.GroupBox4.Controls.Add(Me.lblTaxOnPartsOutput)
        Me.GroupBox4.Controls.Add(Me.lblPartsOutput)
        Me.GroupBox4.Controls.Add(Me.Label3)
        Me.GroupBox4.Controls.Add(Me.lblServiceLaborOutput)
        Me.GroupBox4.Controls.Add(Me.Label1)
        Me.GroupBox4.Location = New System.Drawing.Point(12, 244)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(477, 100)
        Me.GroupBox4.TabIndex = 9
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "SUMMARY CHARGES"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(239, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "TOTAL FEES"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(239, 30)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "TAX ON PARTS"
        '
        'lblTotalOutptut
        '
        Me.lblTotalOutptut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalOutptut.Location = New System.Drawing.Point(369, 60)
        Me.lblTotalOutptut.Name = "lblTotalOutptut"
        Me.lblTotalOutptut.Size = New System.Drawing.Size(64, 13)
        Me.lblTotalOutptut.TabIndex = 7
        '
        'lblTaxOnPartsOutput
        '
        Me.lblTaxOnPartsOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTaxOnPartsOutput.Location = New System.Drawing.Point(369, 30)
        Me.lblTaxOnPartsOutput.Name = "lblTaxOnPartsOutput"
        Me.lblTaxOnPartsOutput.Size = New System.Drawing.Size(64, 13)
        Me.lblTaxOnPartsOutput.TabIndex = 6
        '
        'lblPartsOutput
        '
        Me.lblPartsOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPartsOutput.Location = New System.Drawing.Point(152, 60)
        Me.lblPartsOutput.Name = "lblPartsOutput"
        Me.lblPartsOutput.Size = New System.Drawing.Size(64, 13)
        Me.lblPartsOutput.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(13, 60)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "PARTS"
        '
        'lblServiceLaborOutput
        '
        Me.lblServiceLaborOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblServiceLaborOutput.Location = New System.Drawing.Point(152, 30)
        Me.lblServiceLaborOutput.Name = "lblServiceLaborOutput"
        Me.lblServiceLaborOutput.Size = New System.Drawing.Size(64, 13)
        Me.lblServiceLaborOutput.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(118, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "SERVICE AND LABOR"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.chkTranFlush)
        Me.GroupBox5.Controls.Add(Me.chkRadFlush)
        Me.GroupBox5.Location = New System.Drawing.Point(266, 32)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox5.TabIndex = 9
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "RADIATOR AND TRANSMISSION"
        '
        'chkTranFlush
        '
        Me.chkTranFlush.AutoSize = True
        Me.chkTranFlush.Location = New System.Drawing.Point(19, 67)
        Me.chkTranFlush.Name = "chkTranFlush"
        Me.chkTranFlush.Size = New System.Drawing.Size(146, 17)
        Me.chkTranFlush.TabIndex = 13
        Me.chkTranFlush.Text = "TRANSMISSION FLUSH"
        Me.chkTranFlush.UseVisualStyleBackColor = True
        '
        'chkRadFlush
        '
        Me.chkRadFlush.AutoSize = True
        Me.chkRadFlush.Location = New System.Drawing.Point(19, 31)
        Me.chkRadFlush.Name = "chkRadFlush"
        Me.chkRadFlush.Size = New System.Drawing.Size(120, 17)
        Me.chkRadFlush.TabIndex = 12
        Me.chkRadFlush.Text = "RADIATOR FLUSH"
        Me.chkRadFlush.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(501, 422)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalc)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblTotalOutptut As Label
    Friend WithEvents lblTaxOnPartsOutput As Label
    Friend WithEvents lblPartsOutput As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblServiceLaborOutput As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents chkLubeJob As CheckBox
    Friend WithEvents chkOilChnge As CheckBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txtLabor As TextBox
    Friend WithEvents txtParts As TextBox
    Friend WithEvents chkTireRotation As CheckBox
    Friend WithEvents chkReplaceMuff As CheckBox
    Friend WithEvents chkInspection As CheckBox
    Friend WithEvents chkTranFlush As CheckBox
    Friend WithEvents chkRadFlush As CheckBox
End Class
