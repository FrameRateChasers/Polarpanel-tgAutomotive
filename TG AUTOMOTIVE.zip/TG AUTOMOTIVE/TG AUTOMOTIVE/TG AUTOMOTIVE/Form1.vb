﻿Public Class Form1

    Const oil_change As Decimal = 36.0
    Const lube_job As Decimal = 28.0
    Const radiator_flush As Decimal = 50.0
    Const transmission_flush As Decimal = 120.0
    Const inspection_car As Decimal = 15.0
    Const muffler_replacement As Decimal = 200.0
    Const tire_rotation As Decimal = 20.0
    Const price_per_hr As Decimal = 60.0
    Dim answer As Integer
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click




        Dim decPartsPrice As Decimal

        If Not Decimal.TryParse(txtParts.Text, decPartsPrice) Then
            MsgBox("PLEASE ENTER NUMERIC DIGITS GREATER THAN 0 IN PARTS")
        Else

            lblPartsOutput.Text = decPartsPrice.ToString("c")
            answer = decPartsPrice * 1.06
            lblTaxOnPartsOutput.Text = answer.ToString("c")
        End If

        Dim intLaborMin As Integer
        Dim intFinalPriceForLabor As Integer

        If Not Integer.TryParse(txtLabor.Text, intLaborMin) Then
            MsgBox("PLEASE ENTER NUMERIC DIGITS GREATER THAN 0 IN LABOR")
        Else
            intFinalPriceForLabor = doMath(intLaborMin)

            Dim intTotal As Integer
            intTotal = OilndLube() + RadndTrans() + Misc() + intFinalPriceForLabor
            lblServiceLaborOutput.Text = intTotal.ToString("c")

            Dim answer2 As Integer
            answer2 = intTotal + intFinalPriceForLabor + answer
            lblTotalOutptut.Text = answer2.ToString("c")
        End If
    End Sub



    Private Function OilndLube()

        Dim intSum1 As Decimal
        Dim intSum2 As Decimal

        If chkOilChnge.Checked = True Then
            intSum1 += oil_change
        End If
        If chkLubeJob.Checked = True Then
            intSum2 += lube_job
        End If

        Return intSum1 + intSum2
    End Function

    Private Function RadndTrans()

        Dim intSum1 As Decimal
        Dim intSum2 As Decimal

        If chkRadFlush.Checked = True Then
            intSum1 += radiator_flush
        End If
        If chkTranFlush.Checked = True Then
            intSum2 += transmission_flush
        End If

        Return intSum1 + intSum2
    End Function

    Private Function Misc()

        Dim intSum1 As Decimal
        Dim intSum2 As Decimal
        Dim intSum3 As Decimal

        If chkInspection.Checked = True Then
            intSum1 += radiator_flush
        End If
        If chkReplaceMuff.Checked = True Then
            intSum2 += transmission_flush
        End If
        If chkTireRotation.Checked = True Then
            intSum3 += tire_rotation
        End If

        Return intSum1 + intSum2 + intSum3
    End Function

    Private Function doMath(ByVal int1 As Integer)

        Dim intHold As Integer
        intHold = int1 / 60
        Return intHold * price_per_hr

    End Function

    Private Sub ValidateInput(ByRef x As Boolean)
        Dim num3 As Integer = 1

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Clear()
    End Sub


    Private Sub Clear()

        chkRadFlush.Checked = False
        chkTranFlush.Checked = False
        chkLubeJob.Checked = False
        chkReplaceMuff.Checked = False
        chkTireRotation.Checked = False
        chkOilChnge.Checked = False
        chkInspection.Checked = False

        txtLabor.Text = ""
        txtParts.Text = ""

        lblPartsOutput.Text = ""
        lblServiceLaborOutput.Text = ""
        lblTaxOnPartsOutput.Text = ""
        lblTotalOutptut.Text = ""
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
