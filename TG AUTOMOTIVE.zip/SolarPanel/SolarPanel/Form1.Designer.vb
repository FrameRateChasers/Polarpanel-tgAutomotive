﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblAdditionalPanel = New System.Windows.Forms.Label()
        Me.lblTotalCost = New System.Windows.Forms.Label()
        Me.lblDepositAmnt = New System.Windows.Forms.Label()
        Me.lblBalanceDue = New System.Windows.Forms.Label()
        Me.lblBaseCharge = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.txtNumPanel = New System.Windows.Forms.TextBox()
        Me.txtDepostAmnt = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.chkExpress = New System.Windows.Forms.CheckBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.lblRefund = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(471, 119)
        Me.Button1.TabIndex = 0
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(12, 148)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(247, 96)
        Me.Button2.TabIndex = 1
        Me.Button2.UseVisualStyleBackColor = True
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(322, 183)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(139, 50)
        Me.btnCalc.TabIndex = 2
        Me.btnCalc.Text = "Calculate Charges"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(322, 341)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(139, 50)
        Me.btnClose.TabIndex = 4
        Me.btnClose.Text = "CLOSE"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(322, 270)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(139, 50)
        Me.btnClear.TabIndex = 5
        Me.btnClear.Text = "CLEAR"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(23, 270)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(136, 28)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "BASE CHARGE FOR TWO PANELS:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(23, 308)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(136, 23)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "ADDITIONAL PANELS:"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(23, 341)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(136, 24)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "TOTAL COST:"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(23, 377)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(136, 24)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "DEPOSIT AMOUNT:"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(23, 411)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(136, 23)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "BALANCE DUE:"
        '
        'lblAdditionalPanel
        '
        Me.lblAdditionalPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAdditionalPanel.Location = New System.Drawing.Point(191, 308)
        Me.lblAdditionalPanel.Name = "lblAdditionalPanel"
        Me.lblAdditionalPanel.Size = New System.Drawing.Size(96, 23)
        Me.lblAdditionalPanel.TabIndex = 11
        '
        'lblTotalCost
        '
        Me.lblTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalCost.Location = New System.Drawing.Point(191, 341)
        Me.lblTotalCost.Name = "lblTotalCost"
        Me.lblTotalCost.Size = New System.Drawing.Size(96, 24)
        Me.lblTotalCost.TabIndex = 12
        '
        'lblDepositAmnt
        '
        Me.lblDepositAmnt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDepositAmnt.Location = New System.Drawing.Point(191, 377)
        Me.lblDepositAmnt.Name = "lblDepositAmnt"
        Me.lblDepositAmnt.Size = New System.Drawing.Size(96, 24)
        Me.lblDepositAmnt.TabIndex = 13
        '
        'lblBalanceDue
        '
        Me.lblBalanceDue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBalanceDue.Location = New System.Drawing.Point(191, 410)
        Me.lblBalanceDue.Name = "lblBalanceDue"
        Me.lblBalanceDue.Size = New System.Drawing.Size(96, 24)
        Me.lblBalanceDue.TabIndex = 14
        '
        'lblBaseCharge
        '
        Me.lblBaseCharge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBaseCharge.Location = New System.Drawing.Point(191, 269)
        Me.lblBaseCharge.Name = "lblBaseCharge"
        Me.lblBaseCharge.Size = New System.Drawing.Size(96, 24)
        Me.lblBaseCharge.TabIndex = 15
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(33, 62)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(72, 13)
        Me.Label11.TabIndex = 17
        Me.Label11.Text = "FIRST NAME"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(33, 92)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(68, 13)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "LAST NAME"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(319, 51)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(45, 13)
        Me.Label13.TabIndex = 19
        Me.Label13.Text = "PHONE"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(21, 162)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(116, 13)
        Me.Label14.TabIndex = 20
        Me.Label14.Text = "NUMBER OF PANELS"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(21, 190)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(104, 13)
        Me.Label15.TabIndex = 21
        Me.Label15.Text = "DEPOSIT AMOUNT"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(129, 62)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 22
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(129, 92)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 23
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(306, 89)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 24
        '
        'txtNumPanel
        '
        Me.txtNumPanel.Location = New System.Drawing.Point(143, 159)
        Me.txtNumPanel.Name = "txtNumPanel"
        Me.txtNumPanel.Size = New System.Drawing.Size(100, 20)
        Me.txtNumPanel.TabIndex = 25
        '
        'txtDepostAmnt
        '
        Me.txtDepostAmnt.Location = New System.Drawing.Point(143, 190)
        Me.txtDepostAmnt.Name = "txtDepostAmnt"
        Me.txtDepostAmnt.Size = New System.Drawing.Size(100, 20)
        Me.txtDepostAmnt.TabIndex = 26
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(23, 24)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(146, 13)
        Me.Label16.TabIndex = 27
        Me.Label16.Text = "CUSTOMER INFORMATION"
        '
        'chkExpress
        '
        Me.chkExpress.AutoSize = True
        Me.chkExpress.Location = New System.Drawing.Point(71, 216)
        Me.chkExpress.Name = "chkExpress"
        Me.chkExpress.Size = New System.Drawing.Size(172, 17)
        Me.chkExpress.TabIndex = 29
        Me.chkExpress.Text = "EXPRESS INSTALLAION (5%)"
        Me.chkExpress.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(12, 250)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(471, 200)
        Me.Button3.TabIndex = 30
        Me.Button3.UseVisualStyleBackColor = True
        '
        'lblRefund
        '
        Me.lblRefund.Location = New System.Drawing.Point(23, 411)
        Me.lblRefund.Name = "lblRefund"
        Me.lblRefund.Size = New System.Drawing.Size(138, 23)
        Me.lblRefund.TabIndex = 31
        Me.lblRefund.Text = "REFUND AMOUNT:"
        Me.lblRefund.Visible = False
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(12, 247)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(471, 200)
        Me.Button4.TabIndex = 32
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.ClientSize = New System.Drawing.Size(498, 463)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.lblRefund)
        Me.Controls.Add(Me.chkExpress)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.txtDepostAmnt)
        Me.Controls.Add(Me.txtNumPanel)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.lblBaseCharge)
        Me.Controls.Add(Me.lblBalanceDue)
        Me.Controls.Add(Me.lblDepositAmnt)
        Me.Controls.Add(Me.lblTotalCost)
        Me.Controls.Add(Me.lblAdditionalPanel)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button3)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblAdditionalPanel As Label
    Friend WithEvents lblTotalCost As Label
    Friend WithEvents lblDepositAmnt As Label
    Friend WithEvents lblBalanceDue As Label
    Friend WithEvents lblBaseCharge As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents txtNumPanel As TextBox
    Friend WithEvents txtDepostAmnt As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents chkExpress As CheckBox
    Friend WithEvents Button3 As Button
    Friend WithEvents lblRefund As Label
    Friend WithEvents Button4 As Button
End Class
