﻿Public Class Form1

    Const Express_Price As Double = 1.05
    Const Price_for_Addtional As Double = 300

    Dim dblPriceForAddtionalPanel As Double
    Dim intBasePrice As Integer = 2000
    Dim dblPriceAfterExpressOpition As Double
    Dim dblDepsotAmnt As Double
    Dim dblBalanceDue As Double
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        'calls sub which check textbox
        checkText()

        'show hidden other half of form
        Button4.Visible = False

        'if express installation button is checked execute code below 
        If chkExpress.Checked = True Then

            'error checking
            If txtNumPanel.Text <> "" And txtDepostAmnt.Text <> "" Then
                If IsNumeric(txtDepostAmnt.Text) And IsNumeric(txtNumPanel.Text) Then
                    Dim intHold As Integer
                    intHold = txtNumPanel.Text
                    If intHold <= 1000 And intHold >= 1 Then
                        '1)base charge label will output 2000 dollars
                        lblBaseCharge.Text = intBasePrice.ToString("c")
                        '2)PriceAfterX2()function is called
                        'takes number of panels input(txtNumPanel) and does math
                        'stores value in varible dblPriceForAddtionalPanel
                        dblPriceForAddtionalPanel = PriceAfterX2(txtNumPanel.Text)
                        '3)then stored value in dblPriceForAddtionalPanel will be outputed
                        'in addional panel cost (lblAdditionalPanel)
                        lblAdditionalPanel.Text = dblPriceForAddtionalPanel.ToString("c")

                        '4)TotalCostPriceMath function is called, which adds base price for 2 panels and 
                        'price for addional panels
                        '5)value retured is multipled by 1.05 and then saved in dblPriceAfterExpressOpition
                        dblPriceAfterExpressOpition = TotalCostPriceMath() * Express_Price
                        '6)stored value in dblPriceAfterExpressOpition is outputed in total cost
                        lblTotalCost.Text = dblPriceAfterExpressOpition.ToString("c")

                        '7)takes input in deposit amount(txtDepostAmnt) and saves it in dblDepositAmount varible                         
                        dblDepsotAmnt = CDbl(txtDepostAmnt.Text)
                        lblDepositAmnt.Text = dblDepsotAmnt.ToString("c")

                        '8)calls function BalanceDue which subtracts total cost and depsit amount
                        'and saves it to dblBalanceDue varible
                        dblBalanceDue = BalanceDue()
                        'if balance is positive then they owe money
                        If dblBalanceDue <0 Then
                            dblBalanceDue *= -1
                            lblBalanceDue.Text= dblBalanceDue.ToString("c")
                            'if balance is negitive then refund is given
            ElseIf dblBalanceDue > 0 Then
                            lblRefund.Visible = True
                            lblBalanceDue.Text = dblBalanceDue.ToString("c")
                        End If
                    Else
                        MsgBox("please enter 2-1000")
                    End If
                    MsgBox("please enter numeric digits")
                End If
            Else
                MsgBox("please do not leave panel amount and deposit empty")
            End If


            'if express installation button is not checked execute code below 
        ElseIf chkExpress.Checked = False Then

            'error checking
            If txtNumPanel.Text <> "" And txtDepostAmnt.Text <> "" Then
                If IsNumeric(txtDepostAmnt.Text) And IsNumeric(txtNumPanel.Text) Then
                    Dim intHold As Integer
                    intHold = txtNumPanel.Text
                    If intHold <= 1000 And intHold >= 1 Then
                        '1)base charge label will output 2000 dollars
                        lblBaseCharge.Text = intBasePrice.ToString("c")
                        '2)PriceAfterX2()function is called
                        'takes number of panels input(txtNumPanel) and does math
                        'stores value in varible dblPriceForAddtionalPanel
                        dblPriceForAddtionalPanel = PriceAfterX2(txtNumPanel.Text)
                        '3)then stored value in dblPriceForAddtionalPanel will be outputed
                        'in addional panel cost (lblAdditionalPanel)
                        lblAdditionalPanel.Text = dblPriceForAddtionalPanel.ToString("c")

                        '4)TotalCostPriceMath function is called, which adds base price for 2 panels and 
                        'price for addional panels
                        '5)value retured is multipled by 1.05 and then saved in dblPriceAfterExpressOpition
                        dblPriceAfterExpressOpition = TotalCostPriceMath() ' will be missing * Express_Price
                        '6)stored value in dblPriceAfterExpressOpition is outputed in total cost
                        lblTotalCost.Text = dblPriceAfterExpressOpition.ToString("c")

                        '7)takes input in deposit amount(txtDepostAmnt) and saves it in dblDepositAmount varible                         
                        dblDepsotAmnt = CDbl(txtDepostAmnt.Text)
                        lblDepositAmnt.Text = dblDepsotAmnt.ToString("c")

                        '8)calls function BalanceDue which subtracts total cost and depsit amount
                        'and saves it to dblBalanceDue varible
                        dblBalanceDue = BalanceDue()
                        'if balance is positive then they owe money
                        If dblBalanceDue < 0 Then
                            dblBalanceDue *= -1
                            lblBalanceDue.Text = dblBalanceDue.ToString("c")
                            'if balance is negitive then refund is given
                        ElseIf dblBalanceDue > 0 Then
                            lblRefund.Visible = True
                            lblBalanceDue.Text = dblBalanceDue.ToString("c")
                        End If
                    Else
                        MsgBox("please enter 2-1000")
                    End If
                Else
                    MsgBox("please please enter numeric digits")
                End If
            Else
                MsgBox("please do not leave panel amount and deposit empty")
            End If
        End If



    End Sub



    Private Sub checkText()

        If String.IsNullOrEmpty(TextBox1.Text) Then
            MsgBox("please fill in first name")
        ElseIf String.IsNullOrEmpty(TextBox2.Text) Then
            MsgBox("please fill in first name")
        ElseIf String.IsNullOrEmpty(TextBox3.Text) Then
            MsgBox("please fill in first name")
        End If

    End Sub


    Private Function PriceAfterX2(ByVal num1 As Double)
        Return (num1 - 2) * Price_for_Addtional
    End Function

    Private Function TotalCostPriceMath()
        Return intBasePrice + dblPriceForAddtionalPanel
    End Function

    Private Function BalanceDue()
        Return (dblPriceAfterExpressOpition - dblDepsotAmnt) * -1
    End Function

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        txtDepostAmnt.Text = ""
        txtNumPanel.Text = ""

        lblTotalCost.Text = ""
        lblDepositAmnt.Text = ""
        lblBaseCharge.Text = ""
        lblBalanceDue.Text = ""
        lblAdditionalPanel.Text = ""
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub


End Class
